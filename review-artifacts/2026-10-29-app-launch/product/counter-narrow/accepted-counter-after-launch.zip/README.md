# Run this application locally

Install Bun and Node.js 20.9 or newer. Extract the source ZIP into its own folder, then run:

```sh
bun install --frozen-lockfile
bun test
bun run build
bun run start --port 3216
```

Open http://127.0.0.1:3216 in a modern browser. Choose another free port if needed. These commands start only this downloaded application. Dependencies are installed separately; model weights and personal Studio files are excluded. Pure typed outputs such as a counter or text collection do not need the Studio AI model to run. Model/voice/network features requested by other applications may have their own separate requirements.

This source was produced through the Anascummis local builder. Bounded recipes use a trusted host compiler with model-supplied schema-checked fields; this is not a claim of arbitrary native model-authored software. Read BUILD-PROVENANCE.json when present and BUILD-EVIDENCE.json for the recorded checks and limits. A source/build check is not evidence that unsupported features work. Browser storage belongs to this application origin; different ports or browsers do not automatically share saved data.
