Anascummis Studio local source kit.

Open studio/SOURCE-KIT.json for the exact version, source provenance and payload hashes. Start with studio/LOCAL-INSTALL.md. This is source, not a prebuilt desktop installer. Bun, Node and Python are installed separately; dependency/model downloads require connectivity. The UI can build/start before model/voice setup, and reports unavailable services honestly. No personal data, credentials, caches, installed dependencies, model weights or runtime binaries are included.

Etro0.14.1 is GPL-3.0; its full corresponding source and license are in dependencies/etro. Preserve studio/licenses and the LavaSR license/source. Model and speech licenses apply to their separate downloads.
