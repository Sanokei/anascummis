# User-goal browser journeys

Run from `apps/studio`, with the supported production UI already built, Bun on `PATH` (or `BUN_PATH`), Node and installed Chrome/Chromium (`CHROME_PATH` if needed):

```sh
node scripts/test-user-journeys.mjs --viewport all
node scripts/test-user-journeys.mjs --journey website-pdf-exports --viewport narrow
node scripts/test-user-journeys.mjs --journey bakery-website --require-model
```

`--list` lists concrete user goals. `--output DIR` chooses a new evidence directory; the default is a fresh timestamped `.test-data/user-journeys/` directory. Do not reuse a previous result directory: each journey gets a fresh database and browser session. The runner starts/stops only its own ordinary production server on a free loopback port. It does not build/package implicitly, download models/browsers, install providers, seed mutation APIs, or add scripted inference.

The journeys use visible text entry, actual windows/buttons and a native file chooser. Independent GETs verify saved requests, output state and artifact identity. Actual downloaded HTML, ZIP, PDF and PNG bytes are inspected. Every AI goal is submitted through the interface and reaches a persisted outcome before its real runtime blocker is classified.

The counter application has a bounded ten-minute goal deadline because genuine generation, dependency installation, production build and clean-source QA can exceed a short browser action timeout. Its acceptance criteria are unchanged. Phase/model-call changes are recorded in `progress.json` and the console while work runs, rather than weakening completion checks when it takes longer.

| Journey | User outcome |
| --- | --- |
| `discover-capabilities` | Ask what is possible, then find/open Goals, Work and Software through visible actions. |
| `bakery-website` | Ask for exact bakery copy, inspect it, reload and download it. Missing inference keeps the goal blocked while request preservation/recovery are verified separately. |
| `website-pdf-exports` | Reject an export with no PDF honestly, import a real generated PDF through the chooser, preview a website while the PDF is attached, then export the explicitly requested website HTML/ZIP and PDF/PNG. |
| `public-source-answer` | Save a question and real public-source snapshot, inspect it after reload, and check literal citations only when an actual model-produced answer exists. |
| `later-source-followup` | Answer both Fetch test-location facts using persisted passages/citations after position 800; close/reload; explicitly stage a linked make/web-service question from verified saved copies, with new opt-in and no refetch. Require actual post-answer support decisions, inspect the recorded draft, and keep a maintainer-address control needs_input through one explicit native retry. Inspect its archived prior draft/checks and preserve them across close/reload. The unknown address is not counted as an achieved answer. |
| `counter-application` | Request a counter app, inspect persistent build/artifact, verify the downloaded ZIP hash, independently start the produced task's standalone bundle and exercise heading, keyboard/pointer Increment0→1→2, Reset→0 and reload→0. Rebuild and run the actual downloaded source with matching installed dependencies; require viewport containment and 44px controls in both outputs. A blocked build instead verifies the exact kept request and explicit Resume action without claiming success. |
| `task-list-application` | Request My Tasks with labelled entry/Add/per-item Remove and persistent items, inspect saved progress, download the checked ZIP, run the actual produced bundle, then extract the actual download into a fresh directory and typecheck/test/build/start using its pinned installed dependencies. Both applications must retain items across reload and remove only one duplicate. Explicitly revise to My Week, verify both child outputs, follow its parent link, and preserve the parent's exact record/download. |
| `software-window-routing` | Use ordinary typed status/edit/open/tasks requests to reach the right existing window, retain an unapplied edit, and see honest download/run instructions without any build/revision/chat/goal POST. No inference is required. |

The task-list journey uses a five-minute bound for each owned parent/child task, records every phase/model-call change, and stops a still-running fixture through the visible **Stop build** action before cleanup. A deadline or retained recovery control is a failed/unmet goal, never a completed task list. The downloaded-source check performs a real fresh extraction and build, then starts the actual package script with `bun run start --port <ownedPort>`. It deliberately reuses the matching installed dependency tree and does not claim a fresh online installation. A separate same-origin proof retains the browser context and local address while replacing the produced parent server with the child, then verifies existing items and continued add/remove/reload behavior. It makes no cross-port storage-transfer claim. The source tree and logs remain local diagnostic artifacts.

Exit codes are **0** only when every attempted goal was achieved, **1** for failed assertions/setup, and **2** for blocked user goals. `--allow-blocked` is an explicit diagnostic override; the JSON/HTML report still says `incomplete` and keeps blocked counts. `--require-goals` enforces the default blocking gate even with that diagnostic flag. `--require-model` also fails the gate if the measured local model is unavailable. A health response alone never establishes answer quality or task completion.

Each run writes `report.json` and a browsable `report.html`, with per-journey `result.json`, screenshots, local downloads, a readable Playwright trace and a host log. Source/runner and served HTML/JS/CSS build fingerprints identify what actually ran. Browser HTTP requests outside the owned host/application origins are blocked and recorded; real server-side permitted public-source fetch remains untouched. The trace is rewritten to remove ephemeral session cookies/auth headers before saving. The generated fixture databases, pairing keys, host logs and private data directories are **local diagnostics**; do not commit or publish them. Share selected screenshots, redacted traces and receipts after review. Reports contain no installed credentials or real user inputs because all user content comes from these public fixtures.

The separately invoked checkpoint diagnostic copies a **stopped**, real task-list fixture to a fresh owned data directory. It is not part of the fresh-user matrix and supplies no inference or mutation API seed:

```sh
node scripts/e2e/recover-software.mjs --fixture <stopped-private-data> --task <saved-task-id> --output <fresh-evidence-directory>
```

It verifies the original failed browser check remains paused until a visible Resume click, then requires real validation/artifact success, unchanged native call count/source revision/source hashes, and retained exact failed-check history. It starts the recovered output independently and checks persistence, while proving the original failed fixture/database hashes stayed unchanged. This is recovery of previously generated work, not a claim of a new model-generated application.

To extend the suite, add a record to `journeys.mjs` with `id`, a concrete `goal`, optional `prerequisite`, and `async run(context)`. Context includes `page`, `runtime`, `readApi` (GET only), `send`, `type`, `closeComposer`, `screenshot`, `download`, `zipEntries`, `until`, `assert`, `blocked` and `inspectSoftware(taskId, {name, sourceZip?}, inspectPage)`. The last helper starts only an owned task's real delivered application, optionally rebuilding the supplied downloaded ZIP with matching installed dependencies. Assertions record verified steps; they do not mark the goal complete. `blocked(reason, evidence)` must retain a concrete unmet user outcome. Unsupported or broken behavior must not become a fake pass.
