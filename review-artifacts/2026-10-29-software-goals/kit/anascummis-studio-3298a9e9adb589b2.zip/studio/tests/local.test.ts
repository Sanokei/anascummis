import {test,expect,afterAll} from 'bun:test';
import {mkdir} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {initialSite,validateSite,checkSite,renderSite} from '../core/site';
import {runHarness,objectSchema} from '../core/harness';
import {zip} from '../core/zip';
import {WorkingMemory,countInputTokens} from '../core/working-memory';
test('token budget handles both flat and batched tokenizer results and fails closed',()=>{expect(countInputTokens([1,2,3])).toBe(3);expect(countInputTokens([[1,2,3]])).toBe(3);expect(()=>countInputTokens([])).toThrow();});
import {TurnBoundary,speechChunks} from '../components/turn-timing';
test('small decision packets preserve paginated evidence and resist inherited paths',()=>{const memory=new WorkingMemory(),source={pages:[{text:'A'.repeat(20000)}]};memory.put('pdf',source);source.pages[0].text='changed';expect(JSON.stringify(memory.catalog('pdf')).length).toBeLessThan(600);expect(memory.read('pdf','/pages/0/text',18000).data).toContain('AAAA');expect(memory.read('pdf','/pages/0/text',18000).partial).toBe(true);expect(()=>memory.read('pdf','/toString')).toThrow();expect(()=>memory.read('missing','')).toThrow();});
test('decision evidence exposes complete typed values and lists escaped paths for large records',()=>{const memory=new WorkingMemory();memory.put('small',{count:2});expect(memory.view('small')).toEqual({id:'small',partial:false,value:{count:2}});memory.put('large',{'a/b~c':'x'.repeat(2000)});const large=memory.view('large');expect('paths' in large?large.paths:undefined).toEqual(['','/a~1b~0c']);expect(memory.references()).toEqual(['small','large']);});
test('silence ends a spoken turn without ending idle recording or a short pause',()=>{const boundary=new TurnBoundary();expect(boundary.push(0,5000)).toBe(false);for(let i=0;i<20;i++)expect(boundary.push(.03,20)).toBe(false);expect(boundary.push(0,400)).toBe(false);expect(boundary.push(.03,20)).toBe(false);expect(boundary.push(0,640)).toBe(false);expect(boundary.push(0,20)).toBe(true);const noise=new TurnBoundary();noise.push(.03,50);expect(noise.push(0,1000)).toBe(false);});
test('speech starts with a short sentence and chunks preserve every word',()=>{const text='Your website is ready. '+Array(100).fill('example').join(' ');const chunks=speechChunks(text);expect(chunks[0]).toBe('Your website is ready.');expect(chunks.join(' ')).toBe(text);expect(chunks.every(x=>x.length<=180)).toBe(true);});
const temp=process.env.STUDIO_TEST_DATA||resolve(import.meta.dir,'../.test-data',crypto.randomUUID());await mkdir(temp,{recursive:true});process.env.STUDIO_DATA=temp;process.env.STUDIO_PORT='3298';
const storage=await import('../core/storage'),pdf=await import('../core/pdf'),server=await import('../core/server');
const vault=await import('../core/vault');
const video=await import('../core/video');
const origin='http://127.0.0.1:3298';
let cookie='';
async function request(path:string,body?:unknown,headers:Record<string,string>={}){return server.handle(new Request(origin+path,{method:body===undefined?'GET':'POST',headers:{Host:'127.0.0.1:3298',...(body===undefined?{}:{Origin:origin,'X-Requested-With':'Anascummis',Cookie:cookie,...(body instanceof FormData?{}:{'Content-Type':'application/json'})}),...headers},body:body===undefined?undefined:body instanceof FormData?body:JSON.stringify(body)}));}
afterAll(()=>{vault.lock();storage.db.close();});
test('background goal locks wait for current edits and can be cancelled while waiting',async()=>{
  const key=crypto.randomUUID(),events:string[]=[];let release!:()=>void;
  const first=storage.exclusive(key,async()=>{events.push('first');await new Promise<void>(resolve=>release=resolve);});
  const controller=new AbortController(),cancelled=storage.exclusive(key,async()=>{events.push('cancelled-write');},controller.signal);
  controller.abort();await expect(cancelled).rejects.toThrow();
  const second=storage.exclusive(key,async()=>{events.push('second');},new AbortController().signal);
  release();await first;await second;expect(events).toEqual(['first','second']);
});
test('coordinated goal API preserves full requests and protects stop and continuation controls',async()=>{
  const previousCookie=cookie;
  try{
  const shell=await request('/');cookie=shell.headers.get('set-cookie')!.split(';')[0];
  const project=storage.createProject('Goal API test'),goalText='Set the title, inspect the saved change, and explain it. '+('Keep this requirement. '.repeat(80));
  const denied=await request('/api/goals',{project:project.id,request:goalText},{Origin:'https://evil.example'});expect(denied.status).toBe(403);
  const created=await request('/api/goals',{project:project.id,request:goalText});expect(created.status).toBe(202);
  const goal=await created.json();expect(goal.request).toBe(goalText);expect(goal.status).toBe('queued');
  const listed=await(await request('/api/goals')).json();expect(listed.some((item:any)=>item.id===goal.id)).toBe(true);
  expect((await request('/api/goals/'+crypto.randomUUID())).status).toBe(404);
  expect((await request('/api/goals/'+goal.id+'/stop',{})).status).toBe(200);
  expect((await(await request('/api/goals/'+goal.id)).json()).status).toBe('cancelled');
  const continued=await(await request('/api/goals/'+goal.id+'/resume',{note:'Keep the saved acceptance requirements.'})).json();
  expect(continued.status).toBe('queued');expect(continued.guidance).toBe('Keep the saved acceptance requirements.');expect(continued.request).toBe(goalText);
  expect((await request('/api/goals/'+goal.id+'/resume',{note:'x'.repeat(2001)})).status).toBe(400);
  expect((await request('/api/goals',{project:'missing-project',request:'Do not enqueue this.'})).status).toBe(400);
  }finally{cookie=previousCookie;}
});
test('software detail returns the complete saved goal while list summaries stay bounded',async()=>{
  const {createSoftwareTask,stopSoftwareTask}=await import('../core/software-task');
  const goal='Preserve all of this software request. '+('A concrete acceptance requirement. '.repeat(45));
  const task=await createSoftwareTask(goal,['zip']);
  try{
    const detail=await(await request('/api/software/'+task.id)).json();expect(detail.goal).toBe(goal);
    const list=await(await request('/api/software')).json();expect(list.find((item:any)=>item.id===task.id).goal).toBe(goal.slice(0,800));
  }finally{stopSoftwareTask(task.id);}
});
test('host, origin and local session gates protect mutations',async()=>{expect((await request('/api/projects',{name:'Denied'})).status).toBe(403);const shell=await request('/');cookie=shell.headers.get('set-cookie')!.split(';')[0];expect((await request('/api/projects',{name:'Denied'},{Origin:'https://evil.example'})).status).toBe(403);expect((await request('/api/status',undefined,{Host:'evil.example'})).status).toBe(403);const created=await request('/api/projects',{name:'Wood shop'});expect(created.status).toBe(200);expect((await created.json()).site.name).toBe('Wood shop');});
test('resource activity APIs paginate real records with strict input and existing pairing protections',async()=>{
 const previousCookie=cookie;const shell=await request('/');cookie=shell.headers.get('set-cookie')!.split(';')[0];
 const manager=await import('../core/software-task'),project=storage.createProject('Activity API test');
 const goal=await(await request('/api/goals',{project:project.id,request:'Inspect activity without executing model work.'})).json();
 const software=await manager.createSoftwareTask('Track software activity APIs',['zip']),workId=crypto.randomUUID(),time=Date.now();
 const work={id:workId,projectId:project.id,request:'An existing work record',status:'running',created:time,updated:time,progress:{phase:'working',agent:'website'},events:[{time,phase:'queued',agent:'coordinator'},{time,phase:'working',agent:'website'}]};
 storage.db.query('INSERT INTO work_journal VALUES(?,?,?,?)').run(workId,'running',time,JSON.stringify(work));
 try{
  const routes=['/api/goals/'+goal.id+'/activity','/api/jobs/'+workId+'/activity','/api/software/'+software.id+'/activity'];
  for(const route of routes){
   const first=await request(route+'?limit=1');expect(first.status).toBe(200);const page=await first.json();expect(Array.isArray(page.events)).toBe(true);expect(typeof page.importedHistory).toBe('boolean');expect(typeof page.earlierHistoryMayBeMissing).toBe('boolean');
   if(page.nextCursor){const older=await(await request(route+'?limit=1&before='+page.nextCursor)).json();expect(older.events.every((event:any)=>event.sequence<Number(page.nextCursor))).toBe(true);}
   for(const query of ['limit=0','limit=101','limit=1.5','limit=1e1','limit=','before=0','before=-1','before=01','before=1e2','before=9007199254740992','before='])expect((await request(route+'?'+query)).status).toBe(400);
   expect((await request(route,{})).status).toBe(405);
   expect((await server.handle(new Request(origin+route,{method:'HEAD',headers:{Host:'127.0.0.1:3298'}}))).status).toBe(405);
   expect((await request(route,undefined,{Origin:'https://evil.example'})).status).toBe(403);
  }
  for(const resource of ['goals','jobs','software'])expect((await request('/api/'+resource+'/'+crypto.randomUUID()+'/activity')).status).toBe(404);
  const online={Origin:'https://anascummis.com'};expect((await request(routes[2],undefined,online)).status).toBe(403);
  const pairing=await(await request('/api/software-pairing',undefined,{Cookie:cookie})).json();
  const paired={...online,'X-Anascummis-Pair':pairing.key};const allowed=await request(routes[2],undefined,paired);expect(allowed.status).toBe(200);expect(allowed.headers.get('Access-Control-Allow-Origin')).toBe('https://anascummis.com');
  expect((await request(routes[0],undefined,paired)).status).toBe(403);expect((await request(routes[1],undefined,paired)).status).toBe(403);
  const once=await(await request(routes[1])).json();await request('/api/jobs/'+workId+'/stop',{});await request('/api/jobs/'+workId+'/stop',{});const terminal=await(await request(routes[1])).json();expect(terminal.events.filter((event:any)=>event.phase==='cancelled')).toHaveLength(1);expect(terminal.events.length).toBe(once.events.length+1);
 }finally{manager.stopSoftwareTask(software.id);await request('/api/goals/'+goal.id+'/stop',{});cookie=previousCookie;}
});
test('websites escape source, reject credential leakage and require uploaded assets',()=>{const s=initialSite();s.title='<script>alert(1)</script>';expect(renderSite(s)).not.toContain('<script>alert');s.sections[0].imageId='missing';expect(checkSite(s,[]).ok).toBe(false);delete s.sections[0].imageId;s.subtitle='sk_live_testprivatekey';expect(checkSite(s,[]).ok).toBe(false);expect(()=>validateSite({...s,paymentLink:'https://buy.stripe.com.evil.test/foo'})).toThrow();expect(()=>validateSite({...s,scene:[{id:'x',kind:'box',color:'#ffffff',x:Infinity,y:0,z:0,size:1}]})).toThrow();});
test('standalone website HTML preserves uploaded images and explicit unsupported exports fail',async()=>{
  const project=storage.createProject('Standalone website');
  const image=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jOioAAAAASUVORK5CYII=','base64');
  const id=crypto.randomUUID();await Bun.write(join(storage.DATA,'assets',id),image);storage.db.query('INSERT INTO assets VALUES(?,?,?)').run(id,'logo.png','image/png');
  project.site.sections[0].imageId=id;storage.saveProject(project.id,project.site,'Upload logo');
  const response=await request('/api/projects/'+project.id+'/export?format=html');
  expect(response.status).toBe(200);expect(response.headers.get('content-type')).toStartWith('text/html');
  const html=await response.text();expect(html).toContain('data:image/png;base64,'+image.toString('base64'));expect(html).not.toContain('/api/assets/');
  const bad=await request('/api/projects/'+project.id+'/export?format=pdf');expect(bad.status).toBe(400);
  project.site.scene.push({id:'box',kind:'box',color:'#ffffff',x:0,y:0,z:0,size:1});storage.saveProject(project.id,project.site,'3D scene');
  const scene=await request('/api/projects/'+project.id+'/export?format=html');expect(scene.status).toBe(400);expect((await scene.json()).error).toContain('ZIP');
});
test('manual edits use revision fences and restore preserves history',async()=>{const p=storage.createProject('Test studio');const s={...p.site,title:'Revision one'};expect((await request('/api/projects/'+p.id,{site:s,revision:0})).status).toBe(200);expect((await request('/api/projects/'+p.id,{site:s,revision:0})).status).toBe(400);const restored=storage.restore(p.id,0);expect(restored.revision).toBe(2);expect(restored.site.title).toBe(p.site.title);expect(storage.history(p.id)).toHaveLength(3);});
test('typed harness rejects malformed arguments before execution',async()=>{let calls=0;const values=[{tool:'write',message:''},{value:123},{tool:'write',message:''},{value:456}];const result=await runHarness('write',{},[{name:'write',description:'write',schema:objectSchema({value:{type:'string'}}),run:async()=>{calls++;}}],new AbortController().signal,async()=>values.shift());expect(calls).toBe(0);expect(result.trace.every(x=>!x.ok)).toBe(true);expect(result.trace).toHaveLength(2);});
test('harness executes bounded decisions and stops repeated mutations',async()=>{let calls=0;const values=[{tool:'write',message:''},{value:'x'},{tool:'write',message:''},{value:'x'},{tool:'ask',message:'The repeated write failed. Review the recorded result.'}];const result=await runHarness('write',{},[{name:'write',description:'write',schema:objectSchema({value:{type:'string'}}),run:async()=>{calls++;return {verified:true};}}],new AbortController().signal,async()=>values.shift());expect(calls).toBe(1);expect(result.trace[0].ok).toBe(true);expect(result.trace[1].ok).toBe(false);});
test('real PDF edits preserve original and render verified PNG output',async()=>{const path=join(temp,'sample.pdf');await pdf.pdf({op:'create',output:path,args:{title:'Wood shop',text:'Original sentence.'}});const d=await pdf.importPdf('sample.pdf',new Uint8Array(await Bun.file(path).arrayBuffer()));await pdf.editPdf(d.id,'replace_text',{page:1,find:'Original',replace:'Updated',fontSize:10});expect(JSON.stringify(await pdf.inspectPdf(d.id))).toContain('Updated');const original=await pdf.pdf({op:'inspect',input:join(temp,'documents',d.id,'0.pdf'),args:{pages:[1]}});expect(JSON.stringify(original)).toContain('Original sentence');await pdf.editPdf(d.id,'annotate',{page:1,rect:[40,200,300,250],kind:'comment',comment:'Good evidence.',color:'#bb2233'});const rendered=await pdf.renderPdf(d.id,1,72),bytes=new Uint8Array(await Bun.file(rendered).arrayBuffer());expect([...bytes.slice(0,8)]).toEqual([137,80,78,71,13,10,26,10]);const before=pdf.document(d.id).revision;await expect(pdf.editPdf(d.id,'add_text',{page:1,rect:[-100,0,0,0],text:'Bad'})).rejects.toThrow();expect(pdf.document(d.id).revision).toBe(before);},20000);
test('exported ZIP is readable by an independent archive implementation',async()=>{const path=join(temp,'site.zip');await Bun.write(path,zip({'index.html':new TextEncoder().encode('hello'),'public/assets/image.png':new Uint8Array([1,2,3])}));const executable=process.env.PYTHON_PATH||'python';const p=Bun.spawn([executable,'-c','import sys,zipfile; z=zipfile.ZipFile(sys.argv[1]); assert z.testzip() is None; assert z.read("index.html")==b"hello"; print(len(z.namelist()))',path],{stdout:'pipe',stderr:'pipe'});expect(await p.exited).toBe(0);expect((await new Response(p.stdout).text()).trim()).toBe('2');});
test('private details are encrypted and cannot be combined with research tools',async()=>{await vault.unlock('a sufficiently long passphrase');await vault.save('Tax number','private-test-12345');expect(await Bun.file(join(temp,'vault.enc')).text()).not.toContain('private-test-12345');expect(()=>vault.lookup('toString')).toThrow();await expect(vault.save('__proto__','bad')).rejects.toThrow();const p=storage.createProject('Private test');const rejected=await request('/api/chat',{project:p.id,text:'Read my tax number',savedDetails:['Tax number'],research:true});expect(rejected.status).toBe(400);expect((await rejected.json()).error).toContain('offline turn');vault.lock();await expect(vault.unlock('a wrong but long passphrase')).rejects.toThrow();await vault.unlock('a sufficiently long passphrase');expect(vault.lookup('Tax number')).toBe('private-test-12345');vault.lock();});

test('real FFmpeg combines image and trimmed silent video with narration, captions and checked MP4',async()=>{
  const source=join(temp,'video.mp4'),audio=join(temp,'narration.wav'),image=join(temp,'still.png');
  await video.videoProcess('ffmpeg',['-v','error','-y','-f','lavfi','-i','color=c=blue:s=320x240:r=24','-t','2','-c:v','libx264','-pix_fmt','yuv420p',source]);
  await video.videoProcess('ffmpeg',['-v','error','-y','-f','lavfi','-i','sine=frequency=440:sample_rate=48000','-t','1','-c:a','pcm_s16le',audio]);
  await video.videoProcess('ffmpeg',['-v','error','-y','-f','lavfi','-i','color=c=red:s=320x180','-frames:v','1',image]);
  const [v,a,img]=await Promise.all([source,audio,image].map(async path=>video.importMedia(path.split(/[\\/]/).pop()!,new Uint8Array(await Bun.file(path).arrayBuffer()))));
  expect(v.audio).toBe(false);expect(a.video).toBe(false);expect(img.still).toBe(true);
  const p=video.createVideo('Narrated test',320,240,24),clip={mediaId:v.id,start:.5,duration:1,speed:2,volume:0,caption:"Literal %{exec} : ' [caption]",fit:'cover' as const,fade:.1};
  video.setVideoClip(p.id,0,clip);video.setVideoClip(p.id,1,{...clip,mediaId:img.id,start:0,duration:1,speed:1,caption:'Still screenshot',fit:'contain'});video.setVideoMusic(p.id,{mediaId:a.id,start:0,volume:.4,mode:'replace'});
  const original=await Bun.file(video.mediaPath(v.id)).arrayBuffer(),result=await video.renderVideo(p.id);
  expect(result.checks.decoded).toBe(true);expect(result.videoReady.width).toBe(320);expect(result.videoReady.height).toBe(240);expect(result.videoReady.duration).toBeGreaterThan(1.4);expect(result.videoReady.duration).toBeLessThan(1.8);expect(result.videoReady.audio).toBe(true);expect(result.videoReady.rendered).toBe(true);expect(new Uint8Array(await Bun.file(video.mediaPath(v.id)).arrayBuffer())).toEqual(new Uint8Array(original));
  const credits=await request('/api/media/'+result.videoReady.id+'/credits');expect((await credits.json()).project.clips).toHaveLength(2);
  const range=await request('/api/media/'+result.videoReady.id,undefined,{Range:'bytes=0-15'});expect(range.status).toBe(206);expect((await range.arrayBuffer()).byteLength).toBe(16);expect((await request('/api/media/'+result.videoReady.id,undefined,{Range:'bytes=999999999-'})).status).toBe(416);
  expect(()=>video.setVideoClip(p.id,0,{...clip,start:99})).toThrow('past');expect(()=>video.setVideoClip(p.id,9,clip)).toThrow();expect(()=>video.createVideo('Odd',321,240,24)).toThrow();expect(()=>video.mediaPath('../private')).toThrow();
  await request('/api/media/'+a.id+'/transcript',{text:'My narrated test.'});const tool=video.videoTools(new AbortController().signal).find(t=>t.name==='read_audio_transcript')!;expect((await tool.run({mediaId:a.id,offset:0}) as any).text).toBe('My narrated test.');
},60000);
test('video source tools are opt-in, reject private URLs and cancel native work',async()=>{
  expect(video.videoTools(new AbortController().signal).some(t=>t.name==='download_video')).toBe(false);expect(video.videoTools(new AbortController().signal,true).some(t=>t.name==='capture_web_screenshot')).toBe(true);
  expect(video.youtubeUrl('https://youtu.be/abcdefghijk?list=ignored')).toBe('https://www.youtube.com/watch?v=abcdefghijk');expect(()=>video.youtubeUrl('https://youtube.com.evil.test/watch?v=abcdefghijk')).toThrow();expect(()=>video.youtubeUrl('https://youtube.com/playlist?list=x')).toThrow();
  await expect(video.downloadVideo('https://127.0.0.1/private.mp4','blocked')).rejects.toThrow('Private');await expect(video.captureWebScreenshot('file:///C:/Windows/win.ini','blocked',new AbortController().signal)).rejects.toThrow('HTTPS');
  const control=new AbortController();control.abort();await expect(video.videoProcess('ffmpeg',['-version'],control.signal)).rejects.toThrow();await expect(video.importMedia('invalid.mp4',new TextEncoder().encode('not a video'))).rejects.toThrow();
});

test('persistent software goals keep checkpoints, cancellation and conservative time estimates',async()=>{const manager=await import('../core/software-task'),runner=await import('../core/software-runner');const task=await manager.createSoftwareTask('Create a Bun Nextjs React app with heading Checkpoint Test',['zip']);expect(manager.softwareTask(task.id).goal).toBe(task.goal);expect(await Bun.file(runner.buildPath(runner.taskRoot(task.id),'package.json')).exists()).toBe(true);expect(manager.estimate(task)).toBeUndefined();task.requirements=[{id:'a',description:'A',status:'pending',files:[],tests:[]},{id:'b',description:'B',status:'pending',files:[],tests:[]}];task.milestoneMs=[10000,12000];expect(manager.estimate(task)?.lowSeconds).toBeGreaterThan(0);expect(manager.stopSoftwareTask(task.id).status).toBe('cancelled');expect(manager.resumeSoftwareTask(task.id).goal).toBe(task.goal);manager.stopSoftwareTask(task.id);expect(()=>runner.buildPath(runner.taskRoot(task.id),'../private.txt')).toThrow();expect(()=>runner.buildPath(runner.taskRoot(task.id),'.env.local')).toThrow();expect(()=>runner.buildPath(runner.taskRoot(task.id),'NODE_MODULES/next/package.json')).toThrow();});
test('online build pairing is required and unfinished artifacts cannot be downloaded',async()=>{const shell=await request('/');cookie=shell.headers.get('set-cookie')!.split(';')[0];const paired=await request('/api/software-pairing',undefined,{Cookie:cookie}),pair=await paired.json();expect(pair.key.length).toBe(64);const denied=await server.handle(new Request(origin+'/api/software',{headers:{Host:'127.0.0.1:3298',Origin:'https://anascummis.com'}}));expect(denied.status).toBe(403);const allowed=await server.handle(new Request(origin+'/api/software',{headers:{Host:'127.0.0.1:3298',Origin:'https://anascummis.com','X-Anascummis-Pair':pair.key}}));expect(allowed.status).toBe(200);expect(allowed.headers.get('Access-Control-Allow-Origin')).toBe('https://anascummis.com');const manager=await import('../core/software-task'),task=await manager.createSoftwareTask('Build a Nextjs app with heading Artifact Gate',['zip']);expect((await request('/api/software/'+task.id+'/artifacts/source.zip')).status).toBe(409);manager.stopSoftwareTask(task.id);});
