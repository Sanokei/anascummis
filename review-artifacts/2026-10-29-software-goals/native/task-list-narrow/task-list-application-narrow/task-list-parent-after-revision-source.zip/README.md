# My Tasks

This is a bounded persistent text-collection application compiled by the trusted Anascummis collection compiler (version 1). Native model inference supplies a schema-checked behavior decision; the host grounds literal user fields and generates the implementation and tests. It is not evidence of arbitrary model-authored source. See BUILD-PROVENANCE.json.

Run `bun install --frozen-lockfile`, `bun test`, `bun run build`, then `bun run start --port 3216` and open http://127.0.0.1:3216 (or choose another free port). Bun, Node 20.9+ and an installed browser are separate prerequisites. This pure collection app runs locally without the Studio AI model. The source ZIP contains source and its saved dependency lock; dependencies and model weights are excluded.

Add nonblank text (at most 200 characters) to the initially empty list, up to 100 items. Each Remove button deletes only its own item, even with duplicate text. Items persist across reloads at the same browser origin using localStorage. A heading-only revision retains the same application key. Independently hosted ports/origins do not share browser data. Browser storage can be cleared or denied; failures are shown without clearing the draft or overwriting unreadable saved records. Account sync, collaboration, concurrent-tab conflict resolution, item editing, completion states and remote storage are outside this contract.

The host separately verifies actual production browser interactions, reload persistence, screenshots, build checks and the source snapshot. Passing this contract establishes only those bounded behaviors.
