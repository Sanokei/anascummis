export type Item={id:string;text:string};
export const MAX_ITEMS=100,MAX_TEXT=200;
export function parseItems(raw:string|null):Item[]{
 if(raw===null)return [];
 if(raw.length>150000)throw new Error('Saved tasks exceed this application limit. Existing data was kept.');
 const value=JSON.parse(raw);
 if(!value||value.version!==1||!Array.isArray(value.items)||value.items.length>MAX_ITEMS)throw new Error('Saved tasks have an unsupported format. Existing data was kept.');
 const ids=new Set<string>();
 for(const item of value.items){if(!item||typeof item.id!=='string'||!/^[-a-zA-Z0-9]{1,80}$/.test(item.id)||ids.has(item.id)||typeof item.text!=='string'||!item.text.trim()||item.text.length>MAX_TEXT)throw new Error('Saved tasks have an unsupported item. Existing data was kept.');ids.add(item.id);}
 return value.items.map((item:Item)=>({id:item.id,text:item.text}));
}
export function loadItems(storage:Pick<Storage,'getItem'>,key:string):Item[]{return parseItems(storage.getItem(key));}
export function saveItems(storage:Pick<Storage,'setItem'>,key:string,items:Item[]):void{const raw=JSON.stringify({version:1,items});parseItems(raw);storage.setItem(key,raw);}
