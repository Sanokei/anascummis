export default {output:'standalone',outputFileTracingRoot:process.cwd(),images:{unoptimized:true},experimental:{cpus:1}};
