'use client';
import {useState} from 'react';
const spec={"title":"Bakery Orders","outputLabel":"Count","buttonLabel":"Increment","initial":0,"delta":1,"resetButtonLabel":"Reset"};
export default function Page(){const [value,setValue]=useState(spec.initial);return <main><h1>{spec.title}</h1><output aria-label={spec.outputLabel}>{value}</output><button onClick={()=>setValue(previous=>previous+spec.delta)}>{spec.buttonLabel}</button><button onClick={()=>setValue(spec.initial)}>{spec.resetButtonLabel}</button></main>;}
